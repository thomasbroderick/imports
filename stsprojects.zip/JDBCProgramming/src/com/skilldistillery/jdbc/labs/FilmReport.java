package com.skilldistillery.jdbc.labs;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class FilmReport {
	public void runSQL() {
		String url = "jdbc:mysql://localhost:3306/sdvid";
		String user = "student";
		String pword = "student";
		int totalCost = 0;
		String sql = "SELECT title, replacement_cost FROM film";
		Connection conn = null;
		try {
			conn = DriverManager.getConnection(url, user, pword);
			
			PreparedStatement st = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
			
			ResultSet rs = st.executeQuery();
			while (rs.next()) {
				System.out.println("Film title: " + rs.getString(1));
				System.out.println("Replacement cost " + rs.getDouble(2));
				totalCost += rs.getInt(2);
			}
			System.out.println("Total of replacement costs: " + totalCost);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		FilmReport fr = new FilmReport();
		fr.runSQL();
	}
}
