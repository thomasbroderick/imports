package com.skilldistillery.jdbc.labs;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class ActorAdder {
	Scanner kb = new Scanner(System.in);
	static String[] names = new String[2];
	
	public void getActorName() {
		System.out.println("What is actor's first name?");
		names[0] = kb.next();
		System.out.println("What is actor's last name?");
		names[1] = kb.next();
	}
	
	public void runSQL(String[] names) {
	    String url = "jdbc:mysql://localhost:3306/sdvid";
	    String user = "student";
	    String pword = "student";
	    
	    String sql = "INSERT INTO actor (first_name, last_name) "
	                   + " VALUES (?, ?)";
	    Connection conn = null;
	    try {
	      conn = DriverManager.getConnection(url, user, pword);
	      conn.setAutoCommit(false); // Start transaction
	      PreparedStatement st = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
	      st.setString(1, names[0]);
	      st.setString(2, names[1]);
	      int uc = st.executeUpdate();
	      System.out.println(uc + " actor records created.");
	      // Now get the auto-generated actor IDs:
	      ResultSet keys = st.getGeneratedKeys();
	      while (keys.next()) {
	        System.out.println("New actor ID: " + keys.getInt(1));
	      }
	    }
	    catch (SQLException e) {
	      e.printStackTrace();
	    }
	  }
	
	public static void main(String[] args) {
		ActorAdder aa = new ActorAdder();
		aa.getActorName();
		aa.runSQL(names);

	}

}
