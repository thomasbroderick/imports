package com.skilldisitllery.spring.lotto;
public class PingPongBall {
	private String value;

	public PingPongBall(String v) {
		this.value = v;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

}