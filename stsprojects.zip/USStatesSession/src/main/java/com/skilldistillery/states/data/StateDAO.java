package com.skilldistillery.states.data;

import javax.servlet.http.HttpSession;

public interface StateDAO {
	public State getStateByName(String name);

	public State getStateByAbbreviation(String abbreviation);

	void addState(State state);

	State getNextState(State state, HttpSession session);

	State getPreviousState(State state, HttpSession session);
}
