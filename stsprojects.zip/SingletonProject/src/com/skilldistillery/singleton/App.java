package com.skilldistillery.singleton;

public class App {

	public static void main(String[] args) {
		Singleton s = Singleton.getInstance();
	}

}
