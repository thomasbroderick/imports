package com.skilldistillery.examples.lotto.controllers;

import static org.junit.Assert.assertThat;
import static org.junit.Assert.fail;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.mock.web.MockHttpSession;

public class LottoControllerTests {
	LottoController lc;
	@Before
	public void setUp() throws Exception {
		lc = new LottoController();
	}

	@After
	public void tearDown() throws Exception {
		lc = null;
	}

	@Test
	public void testModelStateInSession(){
	  try {
	    
	    MockHttpSession mockSession = new MockHttpSession();
	    mockSession.perform(get("/GetNumbers.do").param("howmany", "6")
	      .session(mockSession))
	      .andExpect(status().isOk());
	    assertThat(mockSession.getAttribute("history"),
	      hasProperty("size", is("6")));
	  }
	  catch (Exception e) {
	    fail(e.toString());
	  }
	}

}
