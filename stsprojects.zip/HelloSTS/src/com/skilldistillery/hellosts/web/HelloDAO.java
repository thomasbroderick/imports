package com.skilldistillery.hellosts.web;

public interface HelloDAO {
	String getHello();
}
