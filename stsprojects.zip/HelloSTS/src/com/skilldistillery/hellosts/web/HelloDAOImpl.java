package com.skilldistillery.hellosts.web;

public class HelloDAOImpl implements HelloDAO {

	@Override
	public String getHello() {
		return "Hello";
	}

}
