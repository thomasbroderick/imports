package com.skilldistillery.filmquery.app;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
/* convert this project to Maven; add the mysql dep to pom.xml */
/* add the Class.forName("com.mysql.jdbc.Driver") call to register the driver */
/*  this may be added either as a static block or as a ctor */
/*     better as a static block, to allow the load check only 1 time */

import com.skilldistillery.filmquery.database.DatabaseAccessor;
import com.skilldistillery.filmquery.database.DatabaseAccessorObject;
import com.skilldistillery.filmquery.entities.Actor;
import com.skilldistillery.filmquery.entities.Film;

// deeg:
public class FilmQueryApp {

	DatabaseAccessor db = new DatabaseAccessorObject();

	public static void main(String[] args) throws SQLException {
		FilmQueryApp app = new FilmQueryApp();
		// app.test();
		app.launch();
	}

	private void test() throws SQLException {
		List<Film> film = db.getFilmById(1);
		System.out.println(film);
	}

	private void launch() throws SQLException {
		try (Scanner input = new Scanner(System.in)) {
			startUserInterface(input);
		}
	}

	/*
	 * Look up a film by its id. Look up a film by a search keyword. Exit the
	 * application.
	 */
	private void startUserInterface(Scanner input) throws SQLException {
		System.out.println("0- Find by film title: ");
		System.out.println("1- Find by film id: ");
		System.out.println("2- Find film by search keyword: ");
		System.out.println("3- Find Actor by id: ");
		System.out.println("4- Get actors by film id: ");
		System.out.println("5- Add film");
		System.out.println("6- Update film");
		System.out.println("7- Delete film");
		System.out.println("E- Exit: ");

		String choice = null;
		do {
			switch (choice = input.nextLine().toUpperCase()) {
			case "0":
				System.out.print("Enter film title to find: ");
				try {
					String filmTitle = input.nextLine();
					DisplayFilm(db.getFilmByTitle(filmTitle));
				} catch (NumberFormatException e) {
					System.out.println("Film Id is Integer, not title!");
				}
				break;
			case "1":
				System.out.print("Enter film id: ");
				try {
					Integer filmId = Integer.valueOf(input.nextLine());
					DisplayFilm(db.getFilmById(filmId));
				} catch (NumberFormatException e) {
					System.out.println("Film Id is Integer, not title!");
				}
				break;
			case "2":
				System.out.print("Enter search word: ");
				String search = input.nextLine();
				System.out.print("Enter limit, or <CR> if unlimited: ");
				String lim = input.nextLine();
				Integer limInput = lim.length() == 0 ? null : Integer.valueOf(lim);

				if (limInput != null)
					DisplayFilm(db.getFilmByKeyWord(search));
				else
					DisplayFilm(db.getFilmByKeyWord(search, limInput));
				break;
			case "3":
				System.out.print("Enter actor id: ");
				Integer actorId = Integer.valueOf(input.nextLine());
				DisplayActor(db.getActorById(actorId));
				break;
			case "4":
				System.out.print("Enter film id: ");
				Integer filmActor = Integer.valueOf(input.nextLine());
				DisplayActor(db.getActorsByFilmId(filmActor));
				break;
			case "5":
				System.out.print("Enter film title to be added: " );
				  String title = input.nextLine();
				System.out.print("Description: ");
				  String descr = input.nextLine();
				System.out.print("Release year: " );
				  Integer yr = input.nextInt();
				  flushIt(input);
				 System.out.print("Rental length: ");
				   Integer rLen = input.nextInt();
				   flushIt(input);
				 Film newFilm = db.addFilm(new Film(title, descr, yr, 1, rLen));
				 System.out.println(newFilm);
				 DisplayFilm(db.getFilmById(newFilm.getId()));
				 break;
			case "6":
				System.out.print("Enter film title to update: " );
				String updTitle = input.nextLine();
				System.out.print("Description: ");
				   descr = input.nextLine();
				System.out.print("Release year: " );
				   yr = input.nextInt();
				   flushIt(input);
				 System.out.print("Rental length: ");
				   rLen = input.nextInt();
				   flushIt(input);
				Film updFilm = db.updateFilm(db.getFilmByTitle(updTitle), new Film(updTitle, descr, yr, 1, rLen));
				if ( updFilm != null ) {
					 DisplayFilm(db.getFilmById(updFilm.getId()));
				}
				else {
					System.out.println("Film not updated.");
				}
				break;
			case "7":
				System.out.print("Enter film title to delete: " );
				 String delTitle = input.nextLine();
				 Film filmToDelete = db.getFilmByTitle(delTitle);
				 if (filmToDelete != null) {
					 Film delFilm = db.deleteFilm(filmToDelete);
					 if ( delFilm != null ) {
						 System.out.println("Film deleted!");
					 }
					 else
					 {
						 System.out.println("Film not deleted.");
					 }
				 }else
					System.out.println("Film not found!");
				 break;
			case "E":
				System.out.println("Thanks for playing!");
			}

			if (!choice.equals("E")) {
				System.out.println("\n0- Find by film title: ");
				System.out.println("1- Find by film id: ");
				System.out.println("2- Find film by search keyword: ");
				System.out.println("3- Find Actor by id: ");
				System.out.println("4- Get actors by film id: ");
				System.out.println("5- Add film");
				System.out.println("6- Update film");
				System.out.println("7- Delete film");
				System.out.println("E- Exit: ");
			}
		} while (!choice.equals("E"));
	}

	private void flushIt(Scanner scanner) {
		scanner.nextLine();
	}

	private void DisplayFilm(Film film) {
		if (film != null) {
			System.out.println("\n" + film.getTitle() + " " + film.getDescription() + " " + film.getRating()
					+ " Released:  " + film.getReleaseYear() + " Language: " + film.getLanguage());
			System.out.println("Actors: ");
			System.out.println("========");
			for (Actor actor : film.getActors()) {
				System.out.println(actor.getFirstName() + " " + actor.getLastName());
			}
		}
		else {
			System.out.println("No film found!");
		}
	}

	private void DisplayFilm(List<Film> films) {
		Boolean hadOne = false;
		if (films != null) {
			for (Film film : films) {
				hadOne = true;
				DisplayFilm(film);
			}
		}

		if (!hadOne) {
			System.out.println("No match found!");
		}
	}

	private void DisplayActor(List<Actor> actors) {
		Boolean hadOne = false;

		if (actors != null) {
			for (Actor actor : actors) {
				hadOne = true;
				System.out.println(actor.getFirstName() + " " + actor.getLastName());
			}
		}
		if (!hadOne) {
			System.out.println("No match found!");
		}
	}

}
