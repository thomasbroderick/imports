package com.skilldistillery.filmquery.database;

import java.sql.SQLException;
import java.util.List;

import com.skilldistillery.filmquery.entities.Actor;
import com.skilldistillery.filmquery.entities.Film;


/* 
 * convert this project to Maven and add the mysql dependency to pom.xml file
 */

public interface DatabaseAccessor {	
// fields in interface is public, static, final
	
  public Film addFilm(Film film) throws SQLException;
  public Film deleteFilm(Film film) throws SQLException;
  public Film updateFilm(Film existingFilm, Film updatedFilmProperties) throws SQLException;
	
  public List<Film> getFilmById(int filmId) throws SQLException;
  public Film getFilmByTitle(String title) throws SQLException;
  public List<Film> getFilmByKeyWord(String keyword, Integer...limit) throws SQLException;
  public List<Actor> getActorById(int actorId) throws SQLException;
  public List<Actor> getActorsByFilmId(int filmId) throws SQLException;
  public String getFilmLanguage(int filmId) throws SQLException;
}
