package com.skilldistillery.filmquery.database;

import java.sql.Connection;
// Deeg: April 2018: using varargs Integer..., LIMIT, bind vars in prepared stt, try-with-resources
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.skilldistillery.filmquery.entities.Actor;

/*
 *  add the Class.forName("com.mysql.jdbc.Driver") call to register the driver 
 *  this may be added either as a static block or as a ctor 
 *     better as a static block in implementation class, to allow the load check only 1 time 
 * 
 * Implement the getFilmById method that takes an int film ID, and returns a Film object (or null, if the film ID returns no data.)
 * Implement getActorById method that takes an int actor ID, and returns an Actor object (or null, if the actor ID returns no data.)
 * Implement getActorsByFilmId with an appropriate List implementation that will be populated using a ResultSet and returned.
 * Make sure your JDBC code uses PreparedStatement with bind variables instead of concatenating values into SQL strings.
 */

import com.skilldistillery.filmquery.entities.Film;

// deeg:
/*
 * https://github.com/SkillDistillery/SD14/blob/master/sql2/ORM/labs.md
 * Implement an addFilm() method that takes a Film object and inserts it into the database. 
 * It should return the Film object, or null if the insert fails.

Add an "Add New Film" link to your home page that links to a "New Film" form with fields to input film attributes. 
For now, don't worry about language (just hardcode the id for 'English' in your DAO code), categories, or actors.

Implement a new controller method mapped to your new form's action. It should call your DAO's addFilm(), 
and send the result back to your home page which should display the added film.

Modify addFilm() so it retrieves the ID of the newly-inserted film object, and assigns it to the original Film object before returning it.

Make sure your existing Film class and DAO film query methods include film.id in their SELECTs, 
and include the id as an attribute in the returned Film objects.

Modify the query result display in your JSP to include, for each film, it includes a link to 
remove the film, including the film's ID in the link.

Implement deleteFilm() in your DAO, and add a controller method to connect it all together.

Implement a film update operation.
 */
public class DatabaseAccessorObject implements DatabaseAccessor {

	private static final String URL = "jdbc:mysql://localhost:3306/sdvid";
	private static final String DRIVER = "com.mysql.jdbc.Driver";
	private static final String user = "student";
	private static final String pwd = "student";

	// register the mysql driver- required for STS
	static {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			System.err.println("Error loading mySql driver");
			e.printStackTrace();
		}
	}

	@Override
	public Film addFilm(Film film) throws SQLException {
		StringBuilder sql = new StringBuilder(
				"INSERT INTO film (title, description, release_year, language_id, rental_duration) ");
		sql.append(" VALUES (?,?,?,?,?)");
		
		Connection conn = DriverManager.getConnection(URL,  user,  pwd);
		PreparedStatement stmt = conn.prepareStatement(sql.toString(), Statement.RETURN_GENERATED_KEYS);
		try {
			conn.setAutoCommit(false); // START TRANSACTION
		
			stmt.setString(1, film.getTitle());
			stmt.setString(2, film.getDescription());
			stmt.setInt(3, film.getReleaseYear());
			stmt.setInt(4, 1);  // English
			stmt.setInt(5, film.getRentalDuration());
			
		//	System.out.println(stmt);

			if (stmt.executeUpdate() != 1) {
				film = null;
				conn.rollback(); 
			}
			else
			{
			//  get the PK of newly added Film, allowing me to fetch by ID	
				ResultSet keys = stmt.getGeneratedKeys();
				if (keys.next()) {
					int newFilmId = keys.getInt(1);
					film.setId(newFilmId);
				}
				conn.commit();
			}
		} catch (SQLException sqle) {
			// https://stackoverflow.com/questions/15761791/transaction-rollback-on-sqlexception-using-new-try-with-resources-block?utm_medium=organic&utm_source=google_rich_qa&utm_campaign=google_rich_qa
			sqle.printStackTrace();
			if (conn != null) {
				try {
					conn.rollback();
				} catch (SQLException sqle2) {
					System.err.println("Error trying to rollback");
				}
			}
			throw new RuntimeException("Error inserting film " + film);
		}
		conn.close();
		return film;
	}
	
	@Override
	public Film deleteFilm(Film film) throws SQLException {
		StringBuilder sql = new StringBuilder("DELETE FROM film WHERE film.id = ?");
		Connection conn = DriverManager.getConnection(URL, user, pwd);
		PreparedStatement stmt = conn.prepareStatement(sql.toString());
		try {
			conn.setAutoCommit(false);
			stmt.setInt(1, film.getId());
			if (stmt.executeUpdate() > 0) {
				conn.commit();
			}
			else {
				film = null;
				conn.rollback();
			}
			
		} catch (SQLException sqle) {
			// https://stackoverflow.com/questions/15761791/transaction-rollback-on-sqlexception-using-new-try-with-resources-block?utm_medium=organic&utm_source=google_rich_qa&utm_campaign=google_rich_qa
			sqle.printStackTrace();
			if (conn != null) {
				try {
					conn.rollback();
				} catch (SQLException sqle2) {
					System.err.println("Error trying to rollback");
				}
			}
			throw new RuntimeException("Error deleting film " + film);
		}
		conn.close();
		return film;		
	}

	@Override
	public Film updateFilm(Film existingFilm, Film updatedFilmProperties) throws SQLException {
		StringBuilder sql = new StringBuilder(
				"UPDATE film ");
		sql.append(" SET  title = ?, description = ?, release_year = ?,language_id = ?,rental_duration = ?");
		sql.append(" WHERE id = ? " );
		
		Connection conn = DriverManager.getConnection(URL,  user,  pwd);
		PreparedStatement stmt = conn.prepareStatement(sql.toString());
		try {
			conn.setAutoCommit(false); // START TRANSACTION
		
			stmt.setString(1, updatedFilmProperties.getTitle());
			stmt.setString(2, updatedFilmProperties.getDescription());
			stmt.setInt(3, updatedFilmProperties.getReleaseYear());
			stmt.setInt(4, 1);  // English
			stmt.setInt(5, updatedFilmProperties.getRentalDuration());
			stmt.setInt(6, existingFilm.getId());
			
			System.out.println(stmt);
			
		//	System.out.println(stmt);

			if (stmt.executeUpdate() != 1) {
				existingFilm = null;
				conn.rollback(); 
			}
			else
			{
				existingFilm.setTitle(updatedFilmProperties.getTitle());
				existingFilm.setDescription(updatedFilmProperties.getDescription());
				existingFilm.setReleaseYear(updatedFilmProperties.getReleaseYear());
				existingFilm.setLanguage(updatedFilmProperties.getLanguage());
				existingFilm.setRentalDuration(updatedFilmProperties.getRentalDuration());
				conn.commit();
			}
		} catch (SQLException sqle) {
			// https://stackoverflow.com/questions/15761791/transaction-rollback-on-sqlexception-using-new-try-with-resources-block?utm_medium=organic&utm_source=google_rich_qa&utm_campaign=google_rich_qa
			sqle.printStackTrace();
			if (conn != null) {
				try {
					conn.rollback();
				} catch (SQLException sqle2) {
					System.err.println("Error trying to rollback");
				}
			}
			throw new RuntimeException("Error updating film " + existingFilm);
		}
		conn.close();
		return existingFilm;
	} 

	@Override
	public List<Film> getFilmById(int filmId) throws SQLException {
		StringBuilder sql = new StringBuilder(
				"SELECT id, title, description, release_year, language_id, rental_duration, rental_rate, length, replacement_cost, rating, special_features ");
		sql.append(" FROM film WHERE id = ?");

		List<Film> films = new ArrayList<>();

		try (Connection conn = DriverManager.getConnection(URL, user, pwd);
				PreparedStatement stmt = conn.prepareStatement(sql.toString())) {
			// bind
			stmt.setInt(1, filmId);

			setFilmInfo(stmt, films);
		}
		return films;
	}
	
	@Override
	public Film getFilmByTitle(String title) throws SQLException {
		StringBuilder sql = new StringBuilder(
				"SELECT id, title, description, release_year, language_id, rental_duration, rental_rate, length, replacement_cost, rating, special_features ");
		sql.append(" FROM film WHERE title = ?");

		// using list, so this can call setFilmInfoo
		List<Film> films = new ArrayList<>();

		try (Connection conn = DriverManager.getConnection(URL, user, pwd);
				PreparedStatement stmt = conn.prepareStatement(sql.toString())) {
			// bind
			stmt.setString(1, title);

			setFilmInfo(stmt, films);
		}
		if (!films.isEmpty())
			return films.get(0);
		else
			return null;
	}
	
	private void setFilmInfo(PreparedStatement stmt, List<Film> films) throws SQLException {
		try (ResultSet rs = stmt.executeQuery()) {
			while (rs.next()) {
				Integer filmId = rs.getInt(1);

				Film film = new Film(filmId, rs.getString(2), rs.getString(3), rs.getInt(4), rs.getInt(5), rs.getInt(6),
						rs.getDouble(7), rs.getInt(8), rs.getDouble(9), rs.getString(10), rs.getString(11));

				film.setActors(getActorsByFilmId(filmId));
				film.setLanguage(getFilmLanguage(filmId));
				films.add(film);
			}
		}
	}

	@Override
	public List<Film> getFilmByKeyWord(String str, Integer... limit) throws SQLException {
		StringBuilder sql = new StringBuilder("SELECT id, title, description, release_year, ");
		sql.append(" language_id, rental_duration, rental_rate, length, replacement_cost, rating, special_features ");
		sql.append(" FROM film WHERE title LIKE ? OR description LIKE ? ");

		if (limit.length == 1 && limit[0] != null) {
			sql.append(" LIMIT ? ");
		}

		List<Film> films = new ArrayList<>();

		try (Connection conn = DriverManager.getConnection(URL, user, pwd);
				PreparedStatement stmt = conn.prepareStatement(sql.toString())) {

			stmt.setString(1, "%" + str + "%"); // bind title
			stmt.setString(2, "%" + str + "%"); // bind description
			if (limit.length == 1 && limit[0] != null) {
				stmt.setInt(3, limit[0]); // bind vararg limit, since it was supplied (and vararg is just an array)
			}

			setFilmInfo(stmt, films);
		}
		return films;
	}

	@Override
	public List<Actor> getActorById(int actorId) throws SQLException {
		StringBuilder sql = new StringBuilder("SELECT id, first_name, last_name ");
		sql.append(" FROM actor WHERE id = ?");

		List<Actor> actor = new ArrayList<>();

		try (Connection conn = DriverManager.getConnection(URL, user, pwd);
				PreparedStatement stmt = conn.prepareStatement(sql.toString())) {
			// bind
			stmt.setInt(1, actorId);

			try (ResultSet rs = stmt.executeQuery()) {
				if (rs.next()) {
					actor.add(new Actor(rs.getInt(1), rs.getString(2), rs.getString(3)));
					return actor;
				}
			}
		}
		return actor;
	}

	@Override
	public List<Actor> getActorsByFilmId(int filmId) throws SQLException {

		StringBuilder sql = new StringBuilder("select a.id, a.first_name, a.last_name, f.title ");
		sql.append(" from actor a join film_actor fa on a.id = fa.actor_id ");
		sql.append(" join film f on f.id = fa.film_id ");
		sql.append(" where f.id = ? ");

		List<Actor> actors = new ArrayList<>();

		try (Connection conn = DriverManager.getConnection(URL, user, pwd);
				PreparedStatement stmt = conn.prepareStatement(sql.toString())) {
			// bind
			stmt.setInt(1, filmId);

			try (ResultSet rs = stmt.executeQuery()) {
				while (rs.next()) {
					actors.add(new Actor(rs.getInt(1), rs.getString(2), rs.getString(3)));
				}
			}
		}
		return actors;
	}

	@Override
	public String getFilmLanguage(int filmId) throws SQLException {
		StringBuilder sql = new StringBuilder("Select l.name from language l join film f on l.id = f.language_id ");
		sql.append(" where f.id = ? ");

		String language = null;

		try (Connection conn = DriverManager.getConnection(URL, user, pwd);
				PreparedStatement stmt = conn.prepareStatement(sql.toString())) {
			// bind
			stmt.setInt(1, filmId);

			try (ResultSet rs = stmt.executeQuery()) {
				if (rs.next()) {
					language = rs.getString(1); // l.name
				}
			}
		}
		return language;
	}
}
