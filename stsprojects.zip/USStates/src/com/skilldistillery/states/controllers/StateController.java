package com.skilldistillery.states.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.skilldistillery.states.data.StateDAO;

@Controller
public class StateController {
	@Autowired
	private StateDAO sdao;

	public StateDAO getSdao() {
		return sdao;
	}

	public void setSdao(StateDAO sdao) {
		this.sdao = sdao;
	}

	// TODO : Implement a request handler for:
	@RequestMapping(path = "GetStateData.do", params = "name", method = RequestMethod.GET)
	public ModelAndView getByName(@RequestParam("name") String n) {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("WEB-INF/result.jsp");
		mv.addObject("state", sdao.getStateByName(n));
		return mv;
	}

	@RequestMapping(path = "GetStateData.do", params = "abbr", method = RequestMethod.GET)
	public ModelAndView getByAbbr(@RequestParam("abbr") String n) {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("WEB-INF/result.jsp");
		mv.addObject("state", sdao.getStateByAbbreviation(n));
		return mv;
	}

}
