package com.skilldistillery.spring.project;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ProjectController {

	@RequestMapping("route.do")
	public ModelAndView getData(@RequestParam("data") String data ) {
		ModelAndView mv = new ModelAndView();
		String output = data.toUpperCase();
		mv.addObject("output", output);
		mv.setViewName("display.jsp");
		return mv;
	}
	
}
