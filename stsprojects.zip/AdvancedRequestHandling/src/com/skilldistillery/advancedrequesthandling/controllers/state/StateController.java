package com.skilldistillery.advancedrequesthandling.controllers.state;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.skilldistillery.advancedrequesthandling.data.State;
import com.skilldistillery.advancedrequesthandling.data.StateDAO;

@Controller
public class StateController {
	@Autowired
	private StateDAO stateDAO;

	public void setStateDAO(StateDAO stateDAO) {
		this.stateDAO = stateDAO;
	}

	@RequestMapping(path = "GetStateData.do", params = "name", method = RequestMethod.GET)
	public ModelAndView getStateByName(String name) {
		ModelAndView mv = new ModelAndView();
		State s = stateDAO.getStateByName(name);
		mv.addObject("state", s);
		mv.setViewName("result");
		return mv;
	}

	@RequestMapping(path = "GetStateData.do", params = "abbr", method = RequestMethod.GET)
	public ModelAndView getStateByAbbreviation(String abbr) {
		ModelAndView mv = new ModelAndView();
		State s = stateDAO.getStateByAbbreviation(abbr);
		mv.addObject("state", s);
		mv.setViewName("result");
		return mv;
	}

	// TODO : Implement a request handler for:
	// path "NewState.do"
	// method POST
	// command object : State
	// return : ModelAndView
	// view : "WEB-INF/result.jsp"
	// behavior: add state to dao
	@RequestMapping(path = "NewState.do", method = RequestMethod.POST)
	public ModelAndView createState(State state, RedirectAttributes redir) {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("redirect:stateAdded.do");
		stateDAO.addState(state);
		redir.addFlashAttribute(state);
		return mv;
	}
	// -------------------

	@RequestMapping(path = "stateAdded.do", method = RequestMethod.GET)
	public ModelAndView showState(State state) {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("result");
		return mv;
	}
	// TODO : Implement a request handler for:
	// path "stateAdded.do"
	// method GET
	// command object : State
	// return : ModelAndView
	// view : "WEB-INF/result.jsp"; "result" if using
	// InternalResourceViewResolver with prefix/suffix
	// Note: fix other request handler methods to use
	// InternalResourceViewResolver

}
