package com.skilldistillery.states.controllers;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.skilldistillery.states.data.State;
import com.skilldistillery.states.data.StateDAO;

@SessionAttributes("modelState")
@Controller
public class StateController {
	@Autowired
	private StateDAO stateDAO;

	@ModelAttribute("modelState")
	public State initSessionState() {
		return stateDAO.getStateByName("Alabama");
	}

	@RequestMapping(path = "index.do", method = RequestMethod.GET) // modelState from session
	public ModelAndView updateState(@ModelAttribute("modelState") State s) {
		ModelAndView mv = new ModelAndView();
		mv.addObject("modelState", s);
		mv.setViewName("WEB-INF/result.jsp");
		return mv;
	}

	public void setStateDAO(StateDAO stateDAO) {
		this.stateDAO = stateDAO;
	}

	@RequestMapping(path = "GetStateData.do", params = "name", method = RequestMethod.GET)
	public ModelAndView getStateByName(String name) {
		ModelAndView mv = new ModelAndView();
		State s = stateDAO.getStateByName(name);
		mv.addObject("modelState", s);
		mv.setViewName("WEB-INF/result.jsp");
		return mv;
	}

	@RequestMapping(path = "GetStateData.do", params = "abbr", method = RequestMethod.GET)
	public ModelAndView getStateByAbbreviation(String abbr) {
		ModelAndView mv = new ModelAndView();
		State s = stateDAO.getStateByAbbreviation(abbr);
		mv.addObject("modelState", s);
		mv.setViewName("WEB-INF/result.jsp");
		return mv;
	}

	@RequestMapping(path = "previousState.do", method = RequestMethod.GET)
	public ModelAndView getPreviousState(@ModelAttribute("modelState") State s) {
		ModelAndView mv = new ModelAndView();
		s = stateDAO.getPreviousState((State) s);
		mv.addObject("modelState", s);
		mv.setViewName("WEB-INF/result.jsp");
		return mv;

	}

	@RequestMapping(path = "nextState.do", method = RequestMethod.GET)
	public ModelAndView getNextState(@ModelAttribute("modelState") State s) {
		ModelAndView mv = new ModelAndView();
		s = stateDAO.getNextState((State) s);
		mv.addObject("modelState", s);
		mv.setViewName("WEB-INF/result.jsp");
		return mv;

	}
}