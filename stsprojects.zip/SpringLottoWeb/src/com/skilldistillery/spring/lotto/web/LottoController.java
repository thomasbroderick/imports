package com.skilldistillery.spring.lotto.web;

import java.util.List;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.skilldistillery.spring.lotto.Hopper;

@Controller
public class LottoController {
	@Autowired
	private Hopper hopper;

	@RequestMapping("lotto.do")
	public String form() {
		return "form.jsp";
	}

	@RequestMapping("GetNumbers.do")
	public ModelAndView getNumbers(@RequestParam("howmany") int count) {
		hopper.reset();
		ModelAndView mv = new ModelAndView();

		int limit = hopper.getPingPongBalls().size();
		if (count > limit) {
			String errorMessage = "No more than " + limit + " balls!";
			mv.addObject("errorMessage", errorMessage);
		} else {
			List<String> nums = new ArrayList<>();
			for (int i = 0; i < count; i++) {
				nums.add(hopper.drawBall().getValue());
			}
			mv.addObject("listOfNumbers", nums);
		}
		mv.setViewName("form.jsp");
		return mv;
	}
}
