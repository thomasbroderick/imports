package com.skilldistillery.jpavideostore.test;

import static org.junit.jupiter.api.Assertions.*;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.skilldistillery.jpavideostore.entities.Customer;

class CustomerTest {
	private static EntityManagerFactory emf;
	private EntityManager em;
	private Customer c;

	@BeforeAll
	public static void setUpAll() throws Exception {
		emf = Persistence.createEntityManagerFactory("VideoStore");

	}

	@BeforeEach
	public void setUp() throws Exception {
		em = emf.createEntityManager();
		c = em.find(Customer.class, 1);
	}

	@AfterEach
	public void tearDown() throws Exception {
		em.close();
		c = null;
	}

	@AfterAll
	public static void tearDownAll() throws Exception {
		emf.close();

	}

	@Test
	void test_customer_mappings() {
		assertEquals("Mary", c.getFirstName());
		assertEquals("Smithers", c.getLastName());
	}
	
	@Test
	void test_customer_temporal_annotations() {
		assertEquals("2014-05-25", c.getCreateDate().toString());
	}

}
