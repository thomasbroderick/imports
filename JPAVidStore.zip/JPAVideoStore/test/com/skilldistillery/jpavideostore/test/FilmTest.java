package com.skilldistillery.jpavideostore.test;

import static org.junit.jupiter.api.Assertions.*;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.skilldistillery.jpavideostore.entities.Film;

class FilmTest {
	private static EntityManagerFactory emf;
	private EntityManager em;
	private Film f;

	@BeforeAll
	public static void setUpAll() throws Exception {
		emf = Persistence.createEntityManagerFactory("VideoStore");

	}

	@BeforeEach
	public void setUp() throws Exception {
		em = emf.createEntityManager();
		f = em.find(Film.class, 1);
	}

	@AfterEach
	public void tearDown() throws Exception {
		em.close();
	}

	@AfterAll
	public static void tearDownAll() throws Exception {
		emf.close();

	}

	@Test
	void test_film_mappings() {
		assertEquals("ACADEMY DINOSAUR", f.getTitle());
		assertEquals(1993, f.getReleaseYear());
		assertEquals(0.99, f.getRentalRate());
	}
	
	@Test
	void test_film_rating() {
		assertEquals("PG", f.getRating().toString());
	}

}
