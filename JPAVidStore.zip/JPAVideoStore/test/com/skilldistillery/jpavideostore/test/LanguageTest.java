package com.skilldistillery.jpavideostore.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.skilldistillery.jpavideostore.entities.Language;

class LanguageTest {
	private static EntityManagerFactory emf;
	private EntityManager em;
	private Language l;

	@BeforeAll
	public static void setUpAll() throws Exception {
		emf = Persistence.createEntityManagerFactory("VideoStore");

	}

	@BeforeEach
	public void setUp() throws Exception {
		em = emf.createEntityManager();
		l = em.find(Language.class, 1);
	}

	@AfterEach
	public void tearDown() throws Exception {
		em.close();
	}

	@AfterAll
	public static void tearDownAll() throws Exception {
		emf.close();

	}

	@Test
	void test_language_mappings() {
		assertEquals("English", l.getName());
	}

}
