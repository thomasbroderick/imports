package com.skilldistillery.jpavideostore.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.skilldistillery.jpavideostore.client.JPQLLab;
import com.skilldistillery.jpavideostore.entities.Customer;
import com.skilldistillery.jpavideostore.entities.Film;

class JPQLLabTest {

	private static EntityManagerFactory emf;
	private EntityManager em;
	private JPQLLab jpqll;
	@BeforeAll
	public static void setUpAll() throws Exception {
		emf = Persistence.createEntityManagerFactory("VideoStore");
		
	}

	@BeforeEach
	public void setUp() throws Exception {
		em = emf.createEntityManager();
		jpqll = new JPQLLab();
	}

	@AfterEach
	public void tearDown() throws Exception {
		em.close();
	}

	@AfterAll
	public static void tearDownAll() throws Exception {
		emf.close();

	}

	@Test
	void test_get_Range_of_Customers_returns_correct_number_of_customers() {
		List<Customer> custs = jpqll.getRangeOfCustomers(100, 101);
		assertEquals(2, custs.size());
	}
	
	@Test
	void test_get_Customer_Email_by_Name_retuns_customer() {
		String cust = jpqll.getCustomerEmailByName("Peggy", "Myers");
		assertEquals("PEGGY.MYERS@sdvidcustomer.org", cust);
	}
	@Test
	void test_get_Film_by_Title() {
		Film film = jpqll.getFilmByTitle("ACADEMY DINOSAUR");
		assertEquals(1, film.getId());
	}
	@Test
	void test_get_Film_Title_by_Release_Year() {
		List<String> film = jpqll.getFilmTitlesByReleaseYear(2000);
		assertEquals(30, film.size());
	}
	
	

}
