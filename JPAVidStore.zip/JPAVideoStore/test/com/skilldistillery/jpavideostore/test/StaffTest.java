package com.skilldistillery.jpavideostore.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.skilldistillery.jpavideostore.entities.Staff;

class StaffTest {
	private static EntityManagerFactory emf;
	private EntityManager em;
	private Staff s;

	@BeforeAll
	public static void setUpAll() throws Exception {
		emf = Persistence.createEntityManagerFactory("VideoStore");

	}

	@BeforeEach
	public void setUp() throws Exception {
		em = emf.createEntityManager();
		s = em.find(Staff.class, 5);
	}

	@AfterEach
	public void tearDown() throws Exception {
		em.close();
	}

	@AfterAll
	public static void tearDownAll() throws Exception {
		emf.close();

	}

	@Test
	void test_staff_mappings() {
		assertEquals("Steve", s.getFirstName());
		assertEquals("Striker", s.getLastName());
		assertEquals("steve.striker@example.com", s.getEmail());
	}

}
