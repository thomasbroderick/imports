package com.skilldistillery.jpavideostore.entities;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class JPQLClient {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("VideoStore");
		EntityManager em = emf.createEntityManager();

		String queryString = "SELECT s FROM Staff s WHERE s.id < :id";

		List<Staff> results = em.createQuery(queryString, Staff.class).setParameter("id", 10).getResultList();
		for (Staff staff : results) {
			System.out.println(staff.getFirstName() + " " + staff.getLastName());
		}
	}
}
