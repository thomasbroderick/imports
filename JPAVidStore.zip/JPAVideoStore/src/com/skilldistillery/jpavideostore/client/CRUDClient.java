package com.skilldistillery.jpavideostore.client;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.skilldistillery.jpavideostore.entities.Address;
import com.skilldistillery.jpavideostore.entities.Customer;

public class CRUDClient {
	static EntityManagerFactory emf = Persistence.createEntityManagerFactory("VideoStore");
	static EntityManager em = emf.createEntityManager();
	
	public static void main(String[] args) {
		CRUDClient cc = new CRUDClient();
//		cc.updateNullEmails();
//		cc.addNewAddress();
		cc.deleteAddress(730);
		em.close();
		emf.close();
	}
	
	public void updateNullEmails() {
		String queryString = "SELECT c from Customer c WHERE c.email IS NULL OR c.email = ''";
		List<Customer> customers = em.createQuery(queryString, Customer.class).getResultList();
		em.getTransaction().begin();
		for (Customer customer : customers) {
			customer.setEmail(customer.getFirstName() + "." + customer.getLastName() + "@sdcustomer.org");
			
		}
		em.getTransaction().commit();
	}
	
	public Address addNewAddress() {
		Address a = new Address();
		a.setStreet("114 Eclipse Dr");
		a.setState("Colorado");
		a.setCity("Colorado Springs");
		a.setPostalCode("80905");
		a.setPhone("785-550-5504");
		
		em.getTransaction().begin();
		em.persist(a);
		em.flush();
		em.getTransaction().commit();
		
		System.out.println(a);
		return a;
		
	}
	
	public void deleteAddress(int id) {
		em.getTransaction().begin();
		em.remove(em.find(Address.class, id));
		em.getTransaction().commit();
	}
}
