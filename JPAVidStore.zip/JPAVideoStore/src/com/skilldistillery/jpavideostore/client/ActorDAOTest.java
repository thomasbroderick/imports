package com.skilldistillery.jpavideostore.client;

import com.skilldistillery.jpavideostore.data.ActorDAOImpl;
import com.skilldistillery.jpavideostore.entities.Actor;

public class ActorDAOTest {

	public static void main(String[] args) {
		ActorDAOImpl adi = new ActorDAOImpl();
		Actor testActor = new Actor();
		testActor.setFirstName("Jimmy");
		testActor.setLastName("Tables");
//		adi.create(testActor);
//		adi.update(201, testActor);
		adi.destroy(201);

	}

}
