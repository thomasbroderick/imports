package com.skilldistillery.jpavideostore.client;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.skilldistillery.jpavideostore.entities.Film;
import com.skilldistillery.jpavideostore.entities.Staff;

public class IntermediateJPQLClient {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("VideoStore");
		EntityManager em = emf.createEntityManager();

		// String queryString = "SELECT s FROM Staff s ORDER BY s.lastName";
		//
		// List<Staff> staffList = em.createQuery(queryString,
		// Staff.class).getResultList();
		// for (Staff staff : staffList) {
		// System.out.println(staff);
		String queryString = "SELECT a.state, COUNT(a) FROM Address a GROUP BY a.state ORDER BY COUNT(a) DESC";
		List<Object[]> results = em.createQuery(queryString, Object[].class).getResultList();
		for (Object[] objects : results) {
			
			System.out.println(objects[0] + " " + objects[1]);
		}

	}
}
