package com.skilldistillery.jpavideostore.client;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.skilldistillery.jpavideostore.entities.Customer;
import com.skilldistillery.jpavideostore.entities.Film;
import com.skilldistillery.jpavideostore.entities.Staff;

public class JPQLLab {
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("VideoStore");
	EntityManager em = emf.createEntityManager();

	public static void main(String[] args) {
		JPQLLab jpqll = new JPQLLab();
		// List<Customer> results = jpqll.getRangeOfCustomers(100, 110);
		// for (Customer customer : results) {
		// System.out.println(customer.getFirstName() + " " + customer.getLastName() + "
		// "
		// + customer.getEmail());
		// String custEmail = jpqll.getCustomerEmailByName("Peggy", "Myers");
		// System.out.println(custEmail);
		//
		// Film film = jpqll.getFilmByTitle("ACADEMY DINOSAUR");
		// System.out.println(film);

		List<String> strings = jpqll.getFilmTitlesByReleaseYear(2000);
		for (String string : strings) {
			System.out.println(string);
		}
	}

	public List<Customer> getRangeOfCustomers(int minId, int maxId) {
		String queryString = "SELECT c FROM Customer c WHERE c.id BETWEEN :minId AND :maxId";

		List<Customer> results = em.createQuery(queryString, Customer.class).setParameter("minId", minId)
				.setParameter("maxId", maxId).getResultList();
		return results;
	}

	public String getCustomerEmailByName(String fName, String lName) {
		String queryString = "SELECT c.email FROM Customer c WHERE c.firstName = :firstName AND c.lastName = :lastName";

		String result = em.createQuery(queryString, String.class).setParameter("firstName", fName)
				.setParameter("lastName", lName).getResultList().get(0);
		return result;
	}

	public Film getFilmByTitle(String filmTitle) {
		String queryString = "SELECT f FROM Film f WHERE f.title = :ftitle";

		Film result = em.createQuery(queryString, Film.class).setParameter("ftitle", filmTitle).getResultList().get(0);
		return result;
	}

	public List<String> getFilmTitlesByReleaseYear(int year) {
		String queryString = "SELECT f.title FROM Film f WHERE f.releaseYear = :year";

		List<String> result = em.createQuery(queryString, String.class).setParameter("year", year).getResultList();
		return result;
	}

}
