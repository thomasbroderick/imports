package com.skilldistillery.jpavideostore.data;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.skilldistillery.jpavideostore.entities.Actor;

public class ActorDAOImpl implements ActorDAO {

	@Override
	public Actor create(Actor actor) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("VideoStore");
		EntityManager em = emf.createEntityManager();

		em.getTransaction().begin();
		em.persist(actor);
		em.flush();
		em.getTransaction().commit();

		em.close();
		emf.close();
		return actor;
	}

	@Override
	public Actor update(int id, Actor updatedActor) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("VideoStore");
		EntityManager em = emf.createEntityManager();

		em.getTransaction().begin();
		Actor managed = em.find(Actor.class, id);
		managed.setFirstName(updatedActor.getFirstName());
		managed.setLastName(updatedActor.getLastName());
		em.getTransaction().commit();

		em.close();
		emf.close();
		return managed;
	}

	@Override
	public boolean destroy(int id) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("VideoStore");
		EntityManager em = emf.createEntityManager();
		boolean outcome = false;

		em.getTransaction().begin();
		Actor managed = em.find(Actor.class, id);
		if (managed == null) {
			return outcome;
		}
		em.remove(managed);
		em.getTransaction().commit();
		outcome = true;

		em.close();
		emf.close();
		return outcome;
		
	}

}
